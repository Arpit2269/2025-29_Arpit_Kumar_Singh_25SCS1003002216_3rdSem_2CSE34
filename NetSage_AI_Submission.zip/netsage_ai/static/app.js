let allCases = [];
let selectedCaseId = null;

const $ = (id) => document.getElementById(id);

document.querySelectorAll(".nav-item").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".nav-item").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".view").forEach(v => v.classList.remove("active"));
    btn.classList.add("active");
    $("view-" + btn.dataset.view).classList.add("active");
    if (btn.dataset.view === "dashboard") loadDashboard();
    if (btn.dataset.view === "cases") loadCases();
    if (btn.dataset.view === "responsible") loadResponsibleLog();
  });
});

async function api(url, options = {}) {
  const res = await fetch(url, options);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || data.message || "Request failed");
  return data;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;")
    .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function renderBars(containerId, rows, labelKey, valueKey) {
  const el = $(containerId);
  if (!rows.length) {
    el.innerHTML = `<div class="empty-mini">No data yet.</div>`;
    return;
  }
  const max = Math.max(...rows.map(r => Number(r[valueKey]) || 0), 1);
  el.innerHTML = rows.map(r => `
    <div class="bar-row">
      <div class="bar-label"><span>${escapeHtml(r[labelKey])}</span><b>${r[valueKey]}</b></div>
      <div class="bar-track"><div class="bar-fill" style="width:${Math.max(4, (r[valueKey] / max) * 100)}%"></div></div>
    </div>
  `).join("");
}

async function loadDashboard() {
  try {
    const d = await api("/api/dashboard");
    $("stat-total-cases").textContent = d.total_cases;
    $("stat-diagnosed").textContent = d.total_diagnosed;
    $("stat-avg-confidence").textContent = d.avg_confidence + "%";
    $("stat-agreement").textContent = d.total_reviewed ? d.agreement_rate + "%" : "–";
    $("stat-reviewed").textContent = d.total_reviewed;
    $("stat-corrected").textContent = d.corrected_cases;
    $("stat-unreviewed").textContent = d.unreviewed;
    renderBars("category-bars", d.by_category, "category", "c");
    renderBars("severity-bars", d.by_severity, "severity", "c");
    renderBars("review-bars", d.review_breakdown, "decision", "c");
  } catch (e) {
    console.error(e);
  }
}

async function loadCases() {
  try {
    allCases = await api("/api/cases");
    const select = $("category-filter");
    if (select.options.length === 1) {
      [...new Set(allCases.map(c => c.category))].sort().forEach(cat => {
        const opt = document.createElement("option");
        opt.value = cat; opt.textContent = cat;
        select.appendChild(opt);
      });
    }
    renderCaseList();
    if (selectedCaseId) await selectCase(selectedCaseId);
  } catch (e) {
    $("case-list").innerHTML = `<div class="empty-state">${escapeHtml(e.message)}</div>`;
  }
}

$("search-box").addEventListener("input", renderCaseList);
$("category-filter").addEventListener("change", renderCaseList);

function renderCaseList() {
  const q = $("search-box").value.toLowerCase();
  const cat = $("category-filter").value;
  const list = $("case-list");
  list.innerHTML = "";
  allCases.filter(c => {
    return (!q || c.case_id.toLowerCase().includes(q) || c.symptom.toLowerCase().includes(q))
      && (!cat || c.category === cat);
  }).forEach(c => {
    const tpl = $("tpl-case-item").content.cloneNode(true);
    const btn = tpl.querySelector(".case-item");
    tpl.querySelector(".case-id").textContent = c.case_id;
    const pill = tpl.querySelector(".severity-pill");
    pill.textContent = c.severity;
    pill.classList.add("severity-" + c.severity);
    tpl.querySelector(".case-symptom").textContent = c.symptom;
    tpl.querySelector(".category-tag").textContent = c.category;
    const review = tpl.querySelector(".review-tag");
    review.textContent = c.latest_review ? c.latest_review.decision : "Awaiting review";
    if (c.latest_review) review.classList.add(c.latest_review.decision);
    if (c.case_id === selectedCaseId) btn.classList.add("selected");
    btn.addEventListener("click", () => selectCase(c.case_id));
    list.appendChild(btn);
  });
}

async function selectCase(caseId) {
  selectedCaseId = caseId;
  renderCaseList();
  try {
    const c = await api(`/api/case/${encodeURIComponent(caseId)}`);
    renderCaseDetail(c);
  } catch (e) {
    $("case-detail").innerHTML = `<div class="empty-state">${escapeHtml(e.message)}</div>`;
  }
}

function renderCaseDetail(c) {
  $("case-detail-empty").style.display = "none";
  const el = $("case-detail");
  el.style.display = "block";
  const diag = c.latest_diagnosis;
  const review = c.latest_review;

  el.innerHTML = `
    <div class="detail-header">
      <div><h2>${escapeHtml(c.case_id)} — ${escapeHtml(c.category)}</h2>
      <div class="detail-meta"><span class="severity-pill severity-${escapeHtml(c.severity)}">${escapeHtml(c.severity)}</span>
      <span class="category-tag">${escapeHtml(c.osi_layer)}</span><span class="category-tag">${escapeHtml(c.concept)}</span></div></div>
    </div>
    <div class="detail-section"><h4>Symptom</h4><p>${escapeHtml(c.symptom)}</p>
      <h4>Topology Note</h4><p>${escapeHtml(c.topology_note)}</p>
      <h4>Expected Fault (reference)</h4><p class="reference-text">${escapeHtml(c.expected_fault)}</p>
    </div>
    <div class="detail-section"><h4>Show-Command Output — Evidence</h4>
      <div class="show-output">${escapeHtml(c.show_output)}</div>
    </div>
    <div class="detail-section"><div class="btn-row">
      <button class="btn" id="btn-diagnose">🤖 Run AI Diagnosis</button>
      <button class="btn secondary" id="btn-rulecheck">🔍 Run Rule Checker</button>
    </div></div>
    <div class="detail-section" id="diagnosis-section">${diag ? renderDiagnosisBox(diag) : `<div class="notice">Run AI Diagnosis before human review.</div>`}</div>
    <div class="detail-section" id="rulefindings-section">${renderRuleFindings(c.rule_findings || [])}</div>
    <div class="detail-section" id="human-review-section"><h4>Human Review Gate</h4>
      ${review ? renderRecordedReview(review) : renderReviewForm(c.case_id, diag)}
    </div>
  `;

  $("btn-diagnose").addEventListener("click", () => runDiagnosis(c.case_id));
  $("btn-rulecheck").addEventListener("click", () => runRuleCheck(c.case_id));
  attachReviewHandlers(c.case_id);
}

function renderDiagnosisBox(d) {
  return `
    <div class="diagnosis-box">
      <div class="diagnosis-title">AI Diagnosis <span class="confidence-chip">${d.confidence}% confidence</span></div>
      <strong>Root cause:</strong> ${escapeHtml(d.root_cause)}
      <div class="confidence-bar-track"><div class="confidence-bar-fill" style="width:${Math.max(0,Math.min(100,d.confidence))}%"></div></div>
      <div class="meta-line">OSI Layer: ${escapeHtml(d.osi_layer)} · Diagnosis #${d.id ?? d.diagnosis_id ?? "new"}</div>
      <div class="sub-block"><strong>Evidence</strong><ul class="evidence-list">${(d.evidence || []).map(e => `<li>${escapeHtml(e)}</li>`).join("") || "<li>None</li>"}</ul></div>
      <div class="sub-block"><strong>Next command:</strong> <code>${escapeHtml(d.next_command)}</code></div>
      <div class="sub-block"><strong>Proposed fix steps</strong><ol class="fix-list">${(d.fix_steps || []).map(s => `<li>${escapeHtml(s)}</li>`).join("")}</ol></div>
      <div class="notice">⚠ Proposed only — no configuration change has been applied.</div>
    </div>`;
}

function renderRuleFindings(findings) {
  if (!findings.length) return `<div class="notice">No deterministic issue flagged by the rule checker for this evidence.</div>`;
  return `<h4>Deterministic Rule Checker</h4><div class="diagnosis-box">${
    findings.map(f => {
      const checkName = f.check || f.check_name || f.name || "Finding";
      return `<div class="finding-row"><span>${escapeHtml(checkName)}</span><span class="finding-detail">[${escapeHtml(f.severity || "Info")}] ${escapeHtml(f.detail || "")}</span></div>`;
    }).join("")}
  </div>`;
}

function renderReviewForm(caseId, diag, existing = null) {
  if (!diag) return `<div class="notice warning">🔒 Review locked. Run AI Diagnosis first.</div>`;
  const editing = Boolean(existing);
  return `<div class="review-form">
    <div class="notice">${editing ? "Editing the current review. Save the corrected decision below." : "Review is required before the diagnosis is treated as approved."}</div>
    <textarea id="review-notes" placeholder="Required: explain why the diagnosis is accepted, edited, or rejected…">${escapeHtml(existing?.reviewer_notes || "")}</textarea>
    <input id="corrected-root-cause" value="${escapeHtml(existing?.corrected_root_cause || "")}" placeholder="For Edited: enter the corrected root cause">
    <div class="btn-row">
      <button class="btn green" data-decision="Accepted">✔ Accept</button>
      <button class="btn amber" data-decision="Edited">✎ Edited</button>
      <button class="btn red" data-decision="Rejected">✘ Reject</button>
      ${editing ? `<button class="btn secondary" data-cancel-edit="1">Cancel</button>` : ""}
    </div>
  </div>`;
}

function renderRecordedReview(r) {
  return `<div class="review-recorded">
    <b>✓ ${escapeHtml(r.decision)}</b> · ${escapeHtml(r.timestamp)}<br>
    <span>${escapeHtml(r.reviewer_notes)}</span>
    ${r.corrected_root_cause ? `<br><strong>Corrected root cause:</strong> ${escapeHtml(r.corrected_root_cause)}` : ""}
    <div class="btn-row"><button class="btn secondary" data-edit-review="1">✎ Edit Review</button></div>
  </div>`;
}

function attachReviewHandlers(caseId) {
  const current = allCases.find(c => c.case_id === caseId);
  const diag = current?.latest_diagnosis;
  const review = current?.latest_review;

  document.querySelectorAll("[data-edit-review]").forEach(btn => {
    btn.addEventListener("click", () => {
      const section = $("human-review-section");
      if (!section || !diag || !review) return;
      section.innerHTML = `<h4>Human Review Gate</h4>${renderReviewForm(caseId, diag, review)}`;
      attachReviewHandlers(caseId);
    });
  });

  document.querySelectorAll("[data-cancel-edit]").forEach(btn => {
    btn.addEventListener("click", () => {
      const section = $("human-review-section");
      if (!section || !diag || !review) return;
      section.innerHTML = `<h4>Human Review Gate</h4>${renderRecordedReview(review)}`;
      attachReviewHandlers(caseId);
    });
  });

  document.querySelectorAll("[data-decision]").forEach(btn => {
    btn.addEventListener("click", async () => {
      const notes = $("review-notes")?.value.trim() || "";
      const corrected = $("corrected-root-cause")?.value.trim() || null;
      const latestDiag = allCases.find(c => c.case_id === caseId)?.latest_diagnosis;
      const existingReview = allCases.find(c => c.case_id === caseId)?.latest_review;
      if (!latestDiag) return alert("Run AI Diagnosis first.");
      if (!notes) return alert("Reviewer notes are required.");
      if (btn.dataset.decision === "Edited" && !corrected) return alert("Enter the corrected root cause for an Edited review.");
      try {
        await api(`/api/review/${encodeURIComponent(caseId)}`, {
          method: "POST", headers: {"Content-Type": "application/json"},
          body: JSON.stringify({
            decision: btn.dataset.decision,
            notes,
            corrected_root_cause: corrected,
            diagnosis_id: latestDiag.id,
            review_id: existingReview?.id || null
          })
        });
        await loadCases();
        await loadDashboard();
      } catch (e) { alert(e.message); }
    });
  });
}

async function runDiagnosis(caseId) {
  const btn = $("btn-diagnose"); btn.disabled = true; btn.textContent = "⏳ Diagnosing…";
  try {
    await api(`/api/diagnose/${encodeURIComponent(caseId)}`, {method:"POST"});
    await loadCases();
  } catch (e) { alert(e.message); btn.disabled = false; btn.textContent = "🤖 Run AI Diagnosis"; }
}

async function runRuleCheck(caseId) {
  const btn = $("btn-rulecheck"); btn.disabled = true; btn.textContent = "⏳ Checking…";
  try { await api(`/api/rulecheck/${encodeURIComponent(caseId)}`, {method:"POST"}); await selectCase(caseId); }
  catch (e) { alert(e.message); }
  finally { if (btn) { btn.disabled = false; btn.textContent = "🔍 Run Rule Checker"; } }
}

async function loadResponsibleLog() {
  try {
    const items = await api("/api/responsible-log");
    const el = $("responsible-log-list");
    if (!items.length) { el.innerHTML = `<div class="empty-state">No corrected cases recorded.</div>`; return; }
    el.innerHTML = items.map(it => `
      <div class="responsible-item ${escapeHtml(it.decision)}">
        <h4>${escapeHtml(it.case_id)} — ${escapeHtml(it.category)}
          <span class="category-tag">${escapeHtml(it.decision)}</span></h4>
        <div class="row"><div class="col"><div class="label">AI diagnosis (${it.ai_confidence ?? "?"}%)</div>${escapeHtml(it.ai_root_cause || "—")}</div>
        <div class="col"><div class="label">Expected / corrected</div>${escapeHtml(it.corrected_root_cause || it.expected_fault || "—")}</div></div>
        <div class="label">Reviewer reasoning</div><div>${escapeHtml(it.reviewer_notes || "—")}</div>
      </div>`).join("");
  } catch (e) { console.error(e); }
}

loadDashboard();
